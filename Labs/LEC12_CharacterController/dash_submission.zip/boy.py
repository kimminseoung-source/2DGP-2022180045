from math import pi
from pathlib import Path

from pico2d import (
    SDL_KEYDOWN, SDL_KEYUP, SDLK_LEFT, SDLK_RIGHT, SDLK_LSHIFT, SDLK_RSHIFT,
    get_canvas_width, get_time, load_image,
)
from transitions import Machine


class Boy:
    def __init__(self):
        self.x, self.y = 400, 90
        self.frame = 0
        self.face_dir = 1
        self.direction = 0
        self.pressed_keys = set()
        self.move_speed = 200
        self.dash_speed = 400
        self.last_update = get_time()
        image_path = Path(__file__).resolve().parent / 'animation_sheet.png'
        self.image = load_image(str(image_path))
        self.machine = Machine(
            model=self,
            states=['IDLE', 'RUN', 'DASH', 'SLEEP'],
            transitions=[
                {'trigger': 'fall_asleep', 'source': 'IDLE', 'dest': 'SLEEP'},
                {'trigger': 'start_run', 'source': ['IDLE', 'SLEEP', 'DASH'], 'dest': 'RUN'},
                {'trigger': 'start_dash', 'source': ['IDLE', 'SLEEP', 'RUN'], 'dest': 'DASH'},
                {'trigger': 'stop_run', 'source': ['RUN', 'DASH'], 'dest': 'IDLE'},
            ],
            initial='IDLE',
            auto_transitions=False,
        )
        # 초기 상태의 진입 콜백은 직접 호출한다.
        self.on_enter_IDLE()

    def on_enter_IDLE(self):
        self.frame = 0
        self.idle_started = get_time()

    def on_enter_SLEEP(self):
        self.frame = 0

    def on_enter_RUN(self):
        self.frame = 0

    def on_enter_DASH(self):
        self.frame = 0

    def handle_event(self, event):
        if event.type not in (SDL_KEYDOWN, SDL_KEYUP):
            return
        if event.key not in (SDLK_LEFT, SDLK_RIGHT, SDLK_LSHIFT, SDLK_RSHIFT):
            return

        if event.type == SDL_KEYDOWN:
            self.pressed_keys.add(event.key)
        else:
            self.pressed_keys.discard(event.key)

        self.direction = (int(SDLK_RIGHT in self.pressed_keys)
                          - int(SDLK_LEFT in self.pressed_keys))
        if self.direction:
            self.face_dir = self.direction
            dash_pressed = bool(self.pressed_keys & {SDLK_LSHIFT, SDLK_RSHIFT})
            if dash_pressed and self.state != 'DASH':
                self.start_dash()
            elif not dash_pressed and self.state != 'RUN':
                self.start_run()
        elif self.state in ('RUN', 'DASH'):
            self.stop_run()

    def update(self):
        now = get_time()
        elapsed = now - self.last_update
        self.last_update = now

        if self.state in ('IDLE', 'RUN', 'DASH'):
            animation_speed = 16 if self.state == 'DASH' else 8
            self.frame = (self.frame + animation_speed * elapsed) % 8

        if self.state == 'IDLE':
            if now - self.idle_started >= 3.0:
                self.fall_asleep()
        elif self.state in ('RUN', 'DASH'):
            speed = self.dash_speed if self.state == 'DASH' else self.move_speed
            self.x += self.direction * speed * elapsed
            self.x = max(25, min(get_canvas_width() - 25, self.x))

    def draw(self):
        if self.state == 'IDLE':
            row = 300 if self.face_dir == 1 else 200
            self.image.clip_draw(int(self.frame) * 100, row, 100, 100,
                                 self.x, self.y)
        elif self.state in ('RUN', 'DASH'):
            row = 100 if self.face_dir == 1 else 0
            self.image.clip_draw(int(self.frame) * 100, row, 100, 100,
                                 self.x, self.y)
        elif self.state == 'SLEEP':
            # 바라보는 방향의 반대쪽으로 누워 잠든다.
            row = 300 if self.face_dir == 1 else 200
            self.image.clip_composite_draw(0, row, 100, 100,
                                          self.face_dir * pi / 2, '',
                                          self.x, self.y - 25, 100, 100)
